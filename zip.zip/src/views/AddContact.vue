<template>
  <div class="addcontact page">
    <div class="col-4">

          <form action="">
              <div class="form-group mr-1">
                  <label>Nome</label>
                  <input type="text" class="form-control" placeholder="Nome Completo...">
              </div>


              <div class="form-group mr-1">
                  <label>E-mail</label>
                  <input type="email" class="form-control" placeholder="Seu melhor email...">
              </div>

              <div class="form-group mr-1">
                  <label>Contato</label>
                  <input type="phone" class="form-control" placeholder="Telefone/Celular">
              </div>

              <div class="form-group ml-1">
                  <button @click.prevent="saveContact(contact)">Create Contact</button>
              </div>
          </form>
      </div>
  </div>
</template>

<script>

export default {
  name: 'AddContact',
  
  components: {
  },
  methods:{
    saveContact(contact) {
      let contacts = localStorage.getItem('contactsApp');

      contact.id = new Date().getTime();

      if(contacts) {
          //atualizar os contactos na local storage
          contacts = JSON.parse(contacts);
          contacts.push(contact);
      }
      else{ //criar a chave de contactos
          contacts = [contact];
      }

      this.contacts = contacts;

      //atualizar local storage independentemente de novo contacto ou nova adicao
      localStorage.setItem('contactsApp', JSON.stringify(contacts))

      location.reload();
    }
  }
}
</script>
