<template>
  <div class="home page">
    <div class="mw6 center pa3 sans-serif">
    <h1 class="mb4">Contacts</h1>
            
     <div class="col-8 border-left">

          <div class="contact" v-if="contacts != null">
                  
              <div class="col-12 mb-2">
                  <contact v-for="contact in contacts" :key="contact.id" :contact="contact" />
                  <div class="card">
                      <div class="card-body">
                          <h5 class="card-title">{{contact.name}}</h5>

                          <p class="card-text">{{contact.email}}, {{contact.phone}}</p>

                          <a href="#" class="btn btn-sm btn-primary" @click.prevent="editContact(contact)">EDITAR</a>
                          <a href="#" class="btn btn-sm btn-danger" @click.prevent="removeContact(contact.id)">DELETAR</a>
                      </div>

                  </div>
              </div>
          </div>
          <div v-else>Nenhum contacto encontrado!</div>

      </div>
  </div>

  </div>
</template>

<script>
// @ is an alias to /src
import Contact from '@/components/Contact.vue'

export default {
  name: 'ListOfContacts',
  components: {
    Contact,
  }
}
</script>
