<template>
  <div class="pa2 mb3 striped--near-white">
                <header class="b mb2">{{contact.name}}</header>
                <div class="pl2">
                    <p class="mb2">{{contact.phone}}</p>
                    <p class="mb3">{{contact.email}}</p>
                </div>
            </div>
</template>

<script>
export default {
  props:["contact"]
}
</script>